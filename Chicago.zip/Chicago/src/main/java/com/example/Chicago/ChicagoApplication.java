package com.example.Chicago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChicagoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChicagoApplication.class, args);
	}

}
